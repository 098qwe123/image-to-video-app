package com.example.imagetovideoapp.ui;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.imagetovideoapp.R;
import com.example.imagetovideoapp.model.LivePortraitModel;
import com.example.imagetovideoapp.utils.ImageUtils;
import com.example.imagetovideoapp.utils.VideoUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 视频生成界面
 */
public class VideoGenerationActivity extends AppCompatActivity {
    private static final String TAG = "VideoGenerationActivity";
    
    private VideoView resultVideoView;
    private ProgressBar progressBar;
    private TextView progressText;
    private Button shareButton;
    private Button saveButton;
    
    private Uri sourceImageUri;
    private Uri customVideoUri;
    private String effectName;
    private int duration;
    
    private LivePortraitModel model;
    private ExecutorService executor;
    private String outputVideoPath;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_generation);
        
        // 获取传递的参数
        String imageUriString = getIntent().getStringExtra("imageUri");
        if (imageUriString != null) {
            sourceImageUri = Uri.parse(imageUriString);
        }
        
        String customVideoUriString = getIntent().getStringExtra("customVideoUri");
        if (customVideoUriString != null) {
            customVideoUri = Uri.parse(customVideoUriString);
        }
        
        effectName = getIntent().getStringExtra("effectName");
        duration = getIntent().getIntExtra("duration", 60);
        
        // 初始化视图
        initViews();
        
        // 初始化模型
        model = new LivePortraitModel(this);
        executor = Executors.newSingleThreadExecutor();
        
        // 开始生成视频
        startVideoGeneration();
    }
    
    /**
     * 初始化视图组件
     */
    private void initViews() {
        resultVideoView = findViewById(R.id.resultVideoView);
        progressBar = findViewById(R.id.progressBar);
        progressText = findViewById(R.id.progressText);
        shareButton = findViewById(R.id.shareButton);
        saveButton = findViewById(R.id.saveButton);
        
        // 初始状态下禁用按钮
        shareButton.setEnabled(false);
        saveButton.setEnabled(false);
        
        // 设置点击事件
        shareButton.setOnClickListener(v -> {
            VideoUtils.shareVideo(this, outputVideoPath);
        });
        
        saveButton.setOnClickListener(v -> {
            VideoUtils.saveVideoToGallery(this, outputVideoPath);
            Toast.makeText(this, "视频已保存到相册", Toast.LENGTH_SHORT).show();
        });
    }
    
    /**
     * 开始视频生成过程
     */
    private void startVideoGeneration() {
        progressBar.setVisibility(View.VISIBLE);
        progressText.setVisibility(View.VISIBLE);
        
        executor.execute(() -> {
            try {
                // 加载源图像
                Bitmap sourceImage = ImageUtils.loadBitmapFromUri(this, sourceImageUri);
                if (sourceImage == null) {
                    showError("加载源图像失败");
                    return;
                }
                
                // 准备驱动帧
                List<Bitmap> drivingFrames;
                if (customVideoUri != null) {
                    // 使用用户自定义视频作为驱动
                    updateProgress(10, "正在提取用户视频帧...");
                    drivingFrames = VideoUtils.extractFramesFromVideo(this, customVideoUri, duration);
                } else {
                    // 使用预设动画作为驱动
                    updateProgress(10, "正在准备动画模板...");
                    drivingFrames = generateDefaultDrivingFrames(duration);
                }
                
                if (drivingFrames.isEmpty()) {
                    showError("准备驱动帧失败");
                    return;
                }
                
                // 生成视频帧
                updateProgress(20, "正在生成视频帧...");
                List<Bitmap> generatedFrames = new ArrayList<>();
                int totalFrames = drivingFrames.size();
                
                for (int i = 0; i < totalFrames; i++) {
                    // 生成帧
                    Bitmap generatedFrame = model.generateFrame(sourceImage, drivingFrames.get(i));
                    
                    // 应用特效
                    if (!"无特效".equals(effectName)) {
                        generatedFrame = applyEffect(generatedFrame, effectName, i, totalFrames);
                    }
                    
                    generatedFrames.add(generatedFrame);
                    
                    // 更新进度
                    int progress = 20 + (i + 1) * 60 / totalFrames;
                    updateProgress(progress, String.format("正在生成视频帧... %d/%d", i + 1, totalFrames));
                }
                
                // 合成视频
                updateProgress(80, "正在合成视频...");
                File outputDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
                String outputFileName = "generated_" + System.currentTimeMillis() + ".mp4";
                File outputFile = new File(outputDir, outputFileName);
                outputVideoPath = outputFile.getAbsolutePath();
                
                boolean success = VideoUtils.generateVideoFromFrames(
                        generatedFrames, 
                        outputVideoPath, 
                        30 // 帧率
                );
                
                if (!success) {
                    showError("视频合成失败");
                    return;
                }
                
                // 完成
                updateProgress(100, "视频生成完成");
                
                // 显示结果
                runOnUiThread(() -> {
                    resultVideoView.setVideoPath(outputVideoPath);
                    resultVideoView.start();
                    
                    // 启用按钮
                    shareButton.setEnabled(true);
                    saveButton.setEnabled(true);
                });
                
            } catch (Exception e) {
                e.printStackTrace();
                showError("视频生成失败: " + e.getMessage());
            }
        });
    }
    
    /**
     * 生成默认的驱动帧序列
     */
    private List<Bitmap> generateDefaultDrivingFrames(int durationSeconds) {
        // 这里简化处理，实际应用中应该有预设的动画模板
        List<Bitmap> frames = new ArrayList<>();
        int framesCount = durationSeconds * 30; // 假设30fps
        
        // 从资源中加载预设的驱动帧
        for (int i = 0; i < framesCount; i++) {
            // 这里应该从预设模板中加载帧
            // 简化示例，实际实现需要替换
            Bitmap frame = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
            frames.add(frame);
        }
        
        return frames;
    }
    
    /**
     * 应用特效到帧
     */
    private Bitmap applyEffect(Bitmap frame, String effectName, int frameIndex, int totalFrames) {
        // 根据特效名称应用不同的效果
        switch (effectName) {
            case "淡入淡出":
                return VideoUtils.applyFadeEffect(frame, frameIndex, totalFrames);
            case "缩放":
                return VideoUtils.applyZoomEffect(frame, frameIndex, totalFrames);
            case "旋转":
                return VideoUtils.applyRotateEffect(frame, frameIndex, totalFrames);
            case "波纹":
                return VideoUtils.applyRippleEffect(frame, frameIndex, totalFrames);
            case "模糊":
                return VideoUtils.applyBlurEffect(frame, frameIndex, totalFrames);
            case "黑白":
                return VideoUtils.applyBWEffect(frame);
            case "复古":
                return VideoUtils.applyVintageEffect(frame);
            default:
                return frame;
        }
    }
    
    /**
     * 更新进度
     */
    private void updateProgress(int progress, String message) {
        runOnUiThread(() -> {
            progressBar.setProgress(progress);
            progressText.setText(message);
        });
    }
    
    /**
     * 显示错误信息
     */
    private void showError(String message) {
        runOnUiThread(() -> {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            progressBar.setVisibility(View.GONE);
            progressText.setText("生成失败: " + message);
        });
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        // 释放资源
        if (model != null) {
            model.close();
        }
        
        if (executor != null) {
            executor.shutdown();
        }
    }
}
