package com.example.imagetovideoapp.model;

/**
 * 视频模板模型类
 */
public class VideoTemplate {
    private String id;
    private String name;
    private String videoPath;
    private String thumbnailPath;
    private boolean isBuiltIn;

    /**
     * 构造函数 - 用于内置模板
     * 
     * @param id 模板ID
     * @param name 模板名称
     * @param type 模板类型
     * @param thumbnailResourceId 缩略图资源ID
     */
    public VideoTemplate(String id, String name, String type, int thumbnailResourceId) {
        this.id = id;
        this.name = name;
        this.videoPath = type; // 内置模板使用type字段代替路径
        this.thumbnailPath = String.valueOf(thumbnailResourceId);
        this.isBuiltIn = true;
    }

    /**
     * 构造函数 - 用于用户自定义模板
     * 
     * @param id 模板ID
     * @param name 模板名称
     * @param videoPath 视频文件路径
     * @param thumbnailPath 缩略图路径
     */
    public VideoTemplate(String id, String name, String videoPath, String thumbnailPath) {
        this.id = id;
        this.name = name;
        this.videoPath = videoPath;
        this.thumbnailPath = thumbnailPath;
        this.isBuiltIn = false;
    }

    // Getter和Setter方法
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVideoPath() {
        return videoPath;
    }

    public void setVideoPath(String videoPath) {
        this.videoPath = videoPath;
    }

    public String getThumbnailPath() {
        return thumbnailPath;
    }

    public void setThumbnailPath(String thumbnailPath) {
        this.thumbnailPath = thumbnailPath;
    }

    public boolean isBuiltIn() {
        return isBuiltIn;
    }

    public void setBuiltIn(boolean builtIn) {
        isBuiltIn = builtIn;
    }
}
