package com.example.imagetovideoapp.utils;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 图片处理工具类
 */
public class ImageUtils {
    private static final String TAG = "ImageUtils";
    
    /**
     * 创建临时图片URI用于相机拍照
     */
    public static Uri createTempImageUri(Context context) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "TempImage");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From Camera");
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        return context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
    }
    
    /**
     * 从URI加载Bitmap
     */
    public static Bitmap loadBitmapFromUri(Context context, Uri uri) {
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            return BitmapFactory.decodeStream(inputStream);
        } catch (IOException e) {
            Log.e(TAG, "加载图片失败: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * 调整图片大小
     */
    public static Bitmap resizeBitmap(Bitmap bitmap, int maxWidth, int maxHeight) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        
        float ratio = Math.min(
                (float) maxWidth / width,
                (float) maxHeight / height
        );
        
        int newWidth = Math.round(width * ratio);
        int newHeight = Math.round(height * ratio);
        
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);
    }
    
    /**
     * 保存Bitmap到文件
     */
    public static File saveBitmapToFile(Context context, Bitmap bitmap, String filename) {
        File directory = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (directory == null) {
            return null;
        }
        
        File file = new File(directory, filename);
        
        try (FileOutputStream out = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            return file;
        } catch (IOException e) {
            Log.e(TAG, "保存图片失败: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * 生成唯一的图片文件名
     */
    public static String generateUniqueImageName() {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        return "IMG_" + timeStamp + ".jpg";
    }
    
    /**
     * 生成唯一的视频文件名
     */
    public static String generateUniqueVideoName() {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        return "VID_" + timeStamp + ".mp4";
    }
    
    /**
     * 获取图片的主要颜色
     */
    public static int getDominantColor(Bitmap bitmap) {
        if (bitmap == null) {
            return 0;
        }
        
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int size = width * height;
        int pixels[] = new int[size];
        
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        
        int color = 0;
        int r = 0;
        int g = 0;
        int b = 0;
        
        for (int i = 0; i < pixels.length; i++) {
            int pixel = pixels[i];
            r += (pixel >> 16) & 0xff;
            g += (pixel >> 8) & 0xff;
            b += pixel & 0xff;
        }
        
        r /= size;
        g /= size;
        b /= size;
        
        return 0xff000000 | (r << 16) | (g << 8) | b;
    }
}
