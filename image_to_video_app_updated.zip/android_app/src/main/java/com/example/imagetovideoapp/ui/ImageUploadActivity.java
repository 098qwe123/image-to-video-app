package com.example.imagetovideoapp.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.imagetovideoapp.R;
import com.example.imagetovideoapp.utils.ImageUtils;

/**
 * 图片上传和处理界面
 */
public class ImageUploadActivity extends AppCompatActivity {
    private static final int REQUEST_PERMISSION_CODE = 100;
    private static final int REQUEST_IMAGE_PICK = 101;
    private static final int REQUEST_CAMERA = 102;
    
    private ImageView previewImageView;
    private Button galleryButton;
    private Button cameraButton;
    private Button nextButton;
    
    private Uri selectedImageUri;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_upload);
        
        // 初始化视图
        initViews();
        
        // 设置点击事件
        setupClickListeners();
    }
    
    /**
     * 初始化视图组件
     */
    private void initViews() {
        previewImageView = findViewById(R.id.previewImageView);
        galleryButton = findViewById(R.id.galleryButton);
        cameraButton = findViewById(R.id.cameraButton);
        nextButton = findViewById(R.id.nextButton);
        
        // 初始状态下禁用下一步按钮
        nextButton.setEnabled(false);
    }
    
    /**
     * 设置点击事件监听器
     */
    private void setupClickListeners() {
        // 从相册选择图片
        galleryButton.setOnClickListener(v -> {
            if (checkPermissions()) {
                openGallery();
            } else {
                requestPermissions();
            }
        });
        
        // 使用相机拍照
        cameraButton.setOnClickListener(v -> {
            if (checkPermissions()) {
                openCamera();
            } else {
                requestPermissions();
            }
        });
        
        // 下一步按钮
        nextButton.setOnClickListener(v -> {
            if (selectedImageUri != null) {
                // 跳转到特效选择界面
                Intent intent = new Intent(ImageUploadActivity.this, EffectSelectionActivity.class);
                intent.putExtra("imageUri", selectedImageUri.toString());
                startActivity(intent);
            }
        });
    }
    
    /**
     * 检查必要的权限
     */
    private boolean checkPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }
    
    /**
     * 请求必要的权限
     */
    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.CAMERA
                },
                REQUEST_PERMISSION_CODE);
    }
    
    /**
     * 打开相册选择图片
     */
    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_IMAGE_PICK);
    }
    
    /**
     * 打开相机拍照
     */
    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            // 创建临时文件保存照片
            Uri photoUri = ImageUtils.createTempImageUri(this);
            if (photoUri != null) {
                selectedImageUri = photoUri;
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                startActivityForResult(intent, REQUEST_CAMERA);
            }
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // 权限获取成功
                Toast.makeText(this, "权限已授予", Toast.LENGTH_SHORT).show();
            } else {
                // 权限获取失败
                Toast.makeText(this, "需要相关权限才能使用此功能", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_IMAGE_PICK && data != null) {
                // 从相册选择图片返回
                selectedImageUri = data.getData();
                displaySelectedImage();
            } else if (requestCode == REQUEST_CAMERA) {
                // 相机拍照返回
                displaySelectedImage();
            }
        }
    }
    
    /**
     * 显示选中的图片
     */
    private void displaySelectedImage() {
        if (selectedImageUri != null) {
            try {
                // 加载并显示图片
                previewImageView.setImageURI(selectedImageUri);
                
                // 启用下一步按钮
                nextButton.setEnabled(true);
            } catch (Exception e) {
                Toast.makeText(this, "图片加载失败", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }
    }
}
