package com.example.imagetovideoapp.model;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.HashMap;
import java.util.Map;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtException;
import ai.onnxruntime.OrtSession;

/**
 * LivePortrait模型的Android端实现
 * 负责加载ONNX模型并执行推理
 */
public class LivePortraitModel {
    private static final String TAG = "LivePortraitModel";
    private static final int IMAGE_SIZE = 256;
    
    private Context context;
    private OrtEnvironment ortEnvironment;
    private OrtSession kpDetectorSession;
    private OrtSession generatorSession;
    private boolean isInitialized = false;
    
    /**
     * 构造函数
     * @param context 应用上下文
     */
    public LivePortraitModel(Context context) {
        this.context = context;
        initModel();
    }
    
    /**
     * 初始化模型
     */
    private void initModel() {
        try {
            // 初始化ONNX Runtime环境
            ortEnvironment = OrtEnvironment.getEnvironment();
            
            // 加载关键点检测器模型
            InputStream kpDetectorInputStream = context.getAssets().open("kp_detector_quantized.onnx");
            byte[] kpDetectorBytes = new byte[kpDetectorInputStream.available()];
            kpDetectorInputStream.read(kpDetectorBytes);
            kpDetectorInputStream.close();
            
            kpDetectorSession = ortEnvironment.createSession(kpDetectorBytes);
            
            // 加载生成器模型
            InputStream generatorInputStream = context.getAssets().open("generator_quantized.onnx");
            byte[] generatorBytes = new byte[generatorInputStream.available()];
            generatorInputStream.read(generatorBytes);
            generatorInputStream.close();
            
            generatorSession = ortEnvironment.createSession(generatorBytes);
            
            isInitialized = true;
            Log.d(TAG, "模型加载成功");
        } catch (IOException | OrtException e) {
            Log.e(TAG, "模型加载失败: " + e.getMessage());
        }
    }
    
    /**
     * 检查模型是否已初始化
     */
    public boolean isInitialized() {
        return isInitialized;
    }
    
    /**
     * 生成动画帧
     * @param sourceImage 源图像
     * @param drivingImage 驱动图像
     * @return 生成的帧
     */
    public Bitmap generateFrame(Bitmap sourceImage, Bitmap drivingImage) {
        if (!isInitialized) {
            Log.e(TAG, "模型未初始化");
            return null;
        }
        
        try {
            // 预处理图像
            float[][][][] sourceImageTensor = preprocessImage(sourceImage);
            float[][][][] drivingImageTensor = preprocessImage(drivingImage);
            
            // 检测关键点
            Map<String, OnnxTensor> sourceKeypoints = detectKeypoints(sourceImageTensor);
            Map<String, OnnxTensor> drivingKeypoints = detectKeypoints(drivingImageTensor);
            
            // 生成帧
            Bitmap result = generateFrameFromKeypoints(sourceImageTensor, sourceKeypoints, drivingKeypoints);
            
            // 释放资源
            for (OnnxTensor tensor : sourceKeypoints.values()) {
                tensor.close();
            }
            for (OnnxTensor tensor : drivingKeypoints.values()) {
                tensor.close();
            }
            
            return result;
        } catch (OrtException e) {
            Log.e(TAG, "生成帧失败: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * 预处理图像
     */
    private float[][][][] preprocessImage(Bitmap bitmap) {
        // 调整图像大小
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, IMAGE_SIZE, IMAGE_SIZE, true);
        
        // 转换为张量格式 [1, 3, height, width]
        float[][][][] inputTensor = new float[1][3][IMAGE_SIZE][IMAGE_SIZE];
        int[] pixels = new int[IMAGE_SIZE * IMAGE_SIZE];
        resizedBitmap.getPixels(pixels, 0, IMAGE_SIZE, 0, 0, IMAGE_SIZE, IMAGE_SIZE);
        
        for (int y = 0; y < IMAGE_SIZE; y++) {
            for (int x = 0; x < IMAGE_SIZE; x++) {
                int pixel = pixels[y * IMAGE_SIZE + x];
                
                // 归一化到[0,1]
                inputTensor[0][0][y][x] = ((pixel >> 16) & 0xFF) / 255.0f; // R
                inputTensor[0][1][y][x] = ((pixel >> 8) & 0xFF) / 255.0f;  // G
                inputTensor[0][2][y][x] = (pixel & 0xFF) / 255.0f;         // B
            }
        }
        
        return inputTensor;
    }
    
    /**
     * 检测关键点
     */
    private Map<String, OnnxTensor> detectKeypoints(float[][][][] imageTensor) throws OrtException {
        // 创建输入张量
        OnnxTensor inputTensor = OnnxTensor.createTensor(
                ortEnvironment, 
                FloatBuffer.wrap(flatten(imageTensor)), 
                new long[]{1, 3, IMAGE_SIZE, IMAGE_SIZE}
        );
        
        // 准备输入映射
        Map<String, OnnxTensor> inputs = new HashMap<>();
        inputs.put("source", inputTensor);
        
        // 运行模型
        OrtSession.Result result = kpDetectorSession.run(inputs);
        
        // 获取输出
        OnnxTensor keypointsTensor = (OnnxTensor) result.get(0);
        OnnxTensor jacobianTensor = (OnnxTensor) result.get(1);
        
        Map<String, OnnxTensor> outputs = new HashMap<>();
        outputs.put("keypoints", keypointsTensor);
        outputs.put("jacobian", jacobianTensor);
        
        // 释放资源
        inputTensor.close();
        
        return outputs;
    }
    
    /**
     * 从关键点生成帧
     */
    private Bitmap generateFrameFromKeypoints(
            float[][][][] sourceImageTensor,
            Map<String, OnnxTensor> sourceKeypoints,
            Map<String, OnnxTensor> drivingKeypoints) throws OrtException {
        
        // 创建输入张量
        OnnxTensor sourceTensor = OnnxTensor.createTensor(
                ortEnvironment, 
                FloatBuffer.wrap(flatten(sourceImageTensor)), 
                new long[]{1, 3, IMAGE_SIZE, IMAGE_SIZE}
        );
        
        // 准备输入映射
        Map<String, OnnxTensor> inputs = new HashMap<>();
        inputs.put("source_image", sourceTensor);
        inputs.put("kp_source_value", sourceKeypoints.get("keypoints"));
        inputs.put("kp_source_jacobian", sourceKeypoints.get("jacobian"));
        inputs.put("kp_driving_value", drivingKeypoints.get("keypoints"));
        inputs.put("kp_driving_jacobian", drivingKeypoints.get("jacobian"));
        
        // 运行生成器
        OrtSession.Result result = generatorSession.run(inputs);
        
        // 获取输出
        OnnxTensor predictionTensor = (OnnxTensor) result.get(0);
        float[][][][] prediction = (float[][][][]) predictionTensor.getValue();
        
        // 后处理输出
        Bitmap outputBitmap = Bitmap.createBitmap(IMAGE_SIZE, IMAGE_SIZE, Bitmap.Config.ARGB_8888);
        int[] outputPixels = new int[IMAGE_SIZE * IMAGE_SIZE];
        
        for (int y = 0; y < IMAGE_SIZE; y++) {
            for (int x = 0; x < IMAGE_SIZE; x++) {
                int r = (int) (prediction[0][0][y][x] * 255);
                int g = (int) (prediction[0][1][y][x] * 255);
                int b = (int) (prediction[0][2][y][x] * 255);
                
                r = Math.max(0, Math.min(255, r));
                g = Math.max(0, Math.min(255, g));
                b = Math.max(0, Math.min(255, b));
                
                outputPixels[y * IMAGE_SIZE + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
        
        outputBitmap.setPixels(outputPixels, 0, IMAGE_SIZE, 0, 0, IMAGE_SIZE, IMAGE_SIZE);
        
        // 释放资源
        sourceTensor.close();
        predictionTensor.close();
        
        return outputBitmap;
    }
    
    /**
     * 将多维数组展平为一维数组
     */
    private float[] flatten(float[][][][] array) {
        int size = array.length * array[0].length * array[0][0].length * array[0][0][0].length;
        float[] flatArray = new float[size];
        
        int index = 0;
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                for (int k = 0; k < array[i][j].length; k++) {
                    for (int l = 0; l < array[i][j][k].length; l++) {
                        flatArray[index++] = array[i][j][k][l];
                    }
                }
            }
        }
        
        return flatArray;
    }
    
    /**
     * 释放资源
     */
    public void close() {
        try {
            if (kpDetectorSession != null) {
                kpDetectorSession.close();
            }
            if (generatorSession != null) {
                generatorSession.close();
            }
            if (ortEnvironment != null) {
                ortEnvironment.close();
            }
            isInitialized = false;
        } catch (OrtException e) {
            Log.e(TAG, "关闭模型失败: " + e.getMessage());
        }
    }
}
