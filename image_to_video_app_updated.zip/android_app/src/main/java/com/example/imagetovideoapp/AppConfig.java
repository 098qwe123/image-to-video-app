package com.example.imagetovideoapp;

/**
 * 应用程序全局配置类，采用单例模式
 */
public class AppConfig {
    private static AppConfig instance;
    
    // 视频分辨率（默认720P）
    private int videoResolution = 720;
    
    // 视频时长（默认60秒）
    private int videoDuration = 60;
    
    // 视频格式（默认MP4）
    private String videoFormat = "mp4";
    
    // 是否启用GPU加速
    private boolean enableGPU = true;
    
    // 特效质量（0-100）
    private int effectQuality = 80;
    
    private AppConfig() {
        // 私有构造函数
    }
    
    /**
     * 获取单例实例
     */
    public static synchronized AppConfig getInstance() {
        if (instance == null) {
            instance = new AppConfig();
        }
        return instance;
    }
    
    // Getter和Setter方法
    
    public int getVideoResolution() {
        return videoResolution;
    }
    
    public void setVideoResolution(int videoResolution) {
        this.videoResolution = videoResolution;
    }
    
    public int getVideoDuration() {
        return videoDuration;
    }
    
    public void setVideoDuration(int videoDuration) {
        this.videoDuration = videoDuration;
    }
    
    public String getVideoFormat() {
        return videoFormat;
    }
    
    public void setVideoFormat(String videoFormat) {
        this.videoFormat = videoFormat;
    }
    
    public boolean isEnableGPU() {
        return enableGPU;
    }
    
    public void setEnableGPU(boolean enableGPU) {
        this.enableGPU = enableGPU;
    }
    
    public int getEffectQuality() {
        return effectQuality;
    }
    
    public void setEffectQuality(int effectQuality) {
        this.effectQuality = effectQuality;
    }
    
    /**
     * 设置默认视频分辨率
     */
    public void setDefaultVideoResolution(int resolution) {
        this.videoResolution = resolution;
    }
    
    /**
     * 设置默认视频时长
     */
    public void setDefaultVideoDuration(int duration) {
        this.videoDuration = duration;
    }
    
    /**
     * 设置默认视频格式
     */
    public void setDefaultVideoFormat(String format) {
        this.videoFormat = format;
    }
}
