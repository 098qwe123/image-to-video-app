package com.example.imagetovideoapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.imagetovideoapp.R;
import com.example.imagetovideoapp.model.VideoTemplate;
import com.example.imagetovideoapp.utils.ImageUtils;

import java.util.List;

/**
 * 视频模板列表适配器
 */
public class VideoTemplateAdapter extends RecyclerView.Adapter<VideoTemplateAdapter.TemplateViewHolder> {
    private Context context;
    private List<VideoTemplate> templates;
    private OnItemClickListener listener;

    public VideoTemplateAdapter(Context context, List<VideoTemplate> templates) {
        this.context = context;
        this.templates = templates;
    }

    @NonNull
    @Override
    public TemplateViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_video_template, parent, false);
        return new TemplateViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TemplateViewHolder holder, int position) {
        VideoTemplate template = templates.get(position);
        
        holder.templateName.setText(template.getName());
        
        // 设置缩略图
        if (template.isBuiltIn()) {
            // 内置模板使用资源ID
            int resourceId = Integer.parseInt(template.getThumbnailPath());
            holder.templateThumbnail.setImageResource(resourceId);
        } else {
            // 用户自定义模板使用文件路径
            ImageUtils.loadImageFromPath(context, template.getThumbnailPath(), holder.templateThumbnail);
        }
        
        // 设置删除按钮可见性
        if (template.isBuiltIn()) {
            holder.deleteButton.setVisibility(View.GONE);
        } else {
            holder.deleteButton.setVisibility(View.VISIBLE);
        }
        
        // 设置点击事件
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(template);
            }
        });
        
        holder.deleteButton.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDeleteClick(template);
            }
        });
    }

    @Override
    public int getItemCount() {
        return templates.size();
    }
    
    /**
     * 设置点击监听器
     */
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
    
    /**
     * 点击监听器接口
     */
    public interface OnItemClickListener {
        void onItemClick(VideoTemplate template);
        void onDeleteClick(VideoTemplate template);
    }
    
    /**
     * 视频模板ViewHolder
     */
    static class TemplateViewHolder extends RecyclerView.ViewHolder {
        ImageView templateThumbnail;
        TextView templateName;
        ImageButton deleteButton;
        
        public TemplateViewHolder(@NonNull View itemView) {
            super(itemView);
            templateThumbnail = itemView.findViewById(R.id.templateThumbnail);
            templateName = itemView.findViewById(R.id.templateName);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
