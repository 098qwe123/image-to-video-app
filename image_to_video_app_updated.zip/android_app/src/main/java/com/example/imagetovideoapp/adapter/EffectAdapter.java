package com.example.imagetovideoapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.imagetovideoapp.R;
import com.example.imagetovideoapp.model.Effect;

import java.util.List;

/**
 * 特效列表适配器
 */
public class EffectAdapter extends RecyclerView.Adapter<EffectAdapter.EffectViewHolder> {
    private Context context;
    private List<Effect> effects;
    private int selectedPosition = 0; // 默认选中第一个（无特效）

    public EffectAdapter(Context context, List<Effect> effects) {
        this.context = context;
        this.effects = effects;
        
        // 默认选中第一个特效
        if (effects.size() > 0) {
            effects.get(0).setSelected(true);
        }
    }

    @NonNull
    @Override
    public EffectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_effect, parent, false);
        return new EffectViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EffectViewHolder holder, int position) {
        Effect effect = effects.get(position);
        
        holder.effectIcon.setImageResource(effect.getIconResourceId());
        holder.effectName.setText(effect.getName());
        
        // 设置选中状态
        if (effect.isSelected()) {
            holder.effectCard.setCardBackgroundColor(context.getResources().getColor(R.color.selected_effect_bg));
        } else {
            holder.effectCard.setCardBackgroundColor(context.getResources().getColor(R.color.normal_effect_bg));
        }
        
        // 点击事件
        holder.itemView.setOnClickListener(v -> {
            // 更新选中状态
            int previousSelected = selectedPosition;
            selectedPosition = holder.getAdapterPosition();
            
            // 更新数据
            for (int i = 0; i < effects.size(); i++) {
                effects.get(i).setSelected(i == selectedPosition);
            }
            
            // 刷新视图
            notifyItemChanged(previousSelected);
            notifyItemChanged(selectedPosition);
        });
    }

    @Override
    public int getItemCount() {
        return effects.size();
    }
    
    /**
     * 获取当前选中的特效
     */
    public Effect getSelectedEffect() {
        return effects.get(selectedPosition);
    }

    /**
     * 特效ViewHolder
     */
    static class EffectViewHolder extends RecyclerView.ViewHolder {
        CardView effectCard;
        ImageView effectIcon;
        TextView effectName;

        public EffectViewHolder(@NonNull View itemView) {
            super(itemView);
            effectCard = itemView.findViewById(R.id.effectCard);
            effectIcon = itemView.findViewById(R.id.effectIcon);
            effectName = itemView.findViewById(R.id.effectName);
        }
    }
}
