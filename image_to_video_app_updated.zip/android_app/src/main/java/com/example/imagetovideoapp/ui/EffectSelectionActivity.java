package com.example.imagetovideoapp.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.imagetovideoapp.R;
import com.example.imagetovideoapp.adapter.EffectAdapter;
import com.example.imagetovideoapp.model.Effect;
import com.example.imagetovideoapp.utils.ImageUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 特效选择和参数设置界面
 */
public class EffectSelectionActivity extends AppCompatActivity {
    private static final int REQUEST_VIDEO_PICK = 201;
    
    private ImageView previewImageView;
    private RecyclerView effectsRecyclerView;
    private SeekBar durationSeekBar;
    private TextView durationTextView;
    private Button customVideoButton;
    private Button generateButton;
    
    private Uri selectedImageUri;
    private Uri customVideoUri;
    private EffectAdapter effectAdapter;
    private int selectedDuration = 60; // 默认60秒
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_effect_selection);
        
        // 获取传递的图片URI
        String imageUriString = getIntent().getStringExtra("imageUri");
        if (imageUriString != null) {
            selectedImageUri = Uri.parse(imageUriString);
        }
        
        // 初始化视图
        initViews();
        
        // 显示选中的图片
        if (selectedImageUri != null) {
            previewImageView.setImageURI(selectedImageUri);
        }
        
        // 初始化特效列表
        initEffectsList();
        
        // 设置点击事件
        setupClickListeners();
    }
    
    /**
     * 初始化视图组件
     */
    private void initViews() {
        previewImageView = findViewById(R.id.previewImageView);
        effectsRecyclerView = findViewById(R.id.effectsRecyclerView);
        durationSeekBar = findViewById(R.id.durationSeekBar);
        durationTextView = findViewById(R.id.durationTextView);
        customVideoButton = findViewById(R.id.customVideoButton);
        generateButton = findViewById(R.id.generateButton);
        
        // 设置时长选择器
        durationSeekBar.setMax(120); // 最大120秒
        durationSeekBar.setProgress(selectedDuration);
        durationTextView.setText(String.format("%d秒", selectedDuration));
        
        durationSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // 确保至少1秒
                selectedDuration = Math.max(1, progress);
                durationTextView.setText(String.format("%d秒", selectedDuration));
            }
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }
    
    /**
     * 初始化特效列表
     */
    private void initEffectsList() {
        List<Effect> effects = new ArrayList<>();
        
        // 添加预设特效
        effects.add(new Effect("无特效", R.drawable.effect_none, "无特效"));
        effects.add(new Effect("淡入淡出", R.drawable.effect_fade, "淡入淡出效果"));
        effects.add(new Effect("缩放", R.drawable.effect_zoom, "缩放效果"));
        effects.add(new Effect("旋转", R.drawable.effect_rotate, "旋转效果"));
        effects.add(new Effect("波纹", R.drawable.effect_ripple, "波纹效果"));
        effects.add(new Effect("模糊", R.drawable.effect_blur, "模糊效果"));
        effects.add(new Effect("黑白", R.drawable.effect_bw, "黑白效果"));
        effects.add(new Effect("复古", R.drawable.effect_vintage, "复古效果"));
        
        // 设置适配器
        effectAdapter = new EffectAdapter(this, effects);
        effectsRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        effectsRecyclerView.setAdapter(effectAdapter);
    }
    
    /**
     * 设置点击事件监听器
     */
    private void setupClickListeners() {
        // 自定义视频按钮
        customVideoButton.setOnClickListener(v -> {
            openVideoGallery();
        });
        
        // 生成按钮
        generateButton.setOnClickListener(v -> {
            if (selectedImageUri != null) {
                // 获取选中的特效
                Effect selectedEffect = effectAdapter.getSelectedEffect();
                
                // 跳转到视频生成界面
                Intent intent = new Intent(EffectSelectionActivity.this, VideoGenerationActivity.class);
                intent.putExtra("imageUri", selectedImageUri.toString());
                intent.putExtra("duration", selectedDuration);
                intent.putExtra("effectName", selectedEffect.getName());
                
                // 如果有自定义视频，也传递
                if (customVideoUri != null) {
                    intent.putExtra("customVideoUri", customVideoUri.toString());
                }
                
                startActivity(intent);
            } else {
                Toast.makeText(this, "请先选择图片", Toast.LENGTH_SHORT).show();
            }
        });
    }
    
    /**
     * 打开视频选择器
     */
    private void openVideoGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("video/*");
        startActivityForResult(intent, REQUEST_VIDEO_PICK);
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (resultCode == RESULT_OK && requestCode == REQUEST_VIDEO_PICK && data != null) {
            customVideoUri = data.getData();
            Toast.makeText(this, "自定义视频已选择", Toast.LENGTH_SHORT).show();
            
            // 更新UI，显示已选择视频
            customVideoButton.setText("已选择视频");
            customVideoButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_video_selected, 0, 0, 0);
        }
    }
}
