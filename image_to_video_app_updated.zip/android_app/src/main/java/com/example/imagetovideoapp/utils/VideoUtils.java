package com.example.imagetovideoapp.utils;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.util.Log;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * 视频处理工具类
 */
public class VideoUtils {
    private static final String TAG = "VideoUtils";
    private static final int FRAME_RATE = 30;
    private static final int I_FRAME_INTERVAL = 1;
    private static final int TIMEOUT_USEC = 10000;
    
    /**
     * 从视频中提取帧
     */
    public static List<Bitmap> extractFramesFromVideo(Context context, Uri videoUri, int durationSeconds) {
        List<Bitmap> frames = new ArrayList<>();
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        
        try {
            retriever.setDataSource(context, videoUri);
            
            // 获取视频时长（微秒）
            String durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            long videoDurationMs = Long.parseLong(durationStr);
            
            // 计算需要提取的帧数
            int totalFrames = durationSeconds * FRAME_RATE;
            long interval = videoDurationMs * 1000 / totalFrames;
            
            // 提取帧
            for (int i = 0; i < totalFrames; i++) {
                long timeUs = i * interval;
                Bitmap bitmap = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                
                if (bitmap != null) {
                    // 调整大小为标准尺寸
                    bitmap = ImageUtils.resizeBitmap(bitmap, 256, 256);
                    frames.add(bitmap);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "提取视频帧失败: " + e.getMessage());
        } finally {
            try {
                retriever.release();
            } catch (Exception e) {
                Log.e(TAG, "释放MediaMetadataRetriever失败: " + e.getMessage());
            }
        }
        
        return frames;
    }
    
    /**
     * 从帧序列生成视频
     */
    public static boolean generateVideoFromFrames(List<Bitmap> frames, String outputPath, int frameRate) {
        if (frames.isEmpty()) {
            return false;
        }
        
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        
        try {
            // 获取第一帧的尺寸
            Bitmap firstFrame = frames.get(0);
            int width = firstFrame.getWidth();
            int height = firstFrame.getHeight();
            
            // 配置视频编码器
            MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            format.setInteger(MediaFormat.KEY_BIT_RATE, width * height * 4);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, frameRate);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, I_FRAME_INTERVAL);
            
            // 创建编码器
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();
            
            // 创建媒体混合器
            muxer = new MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            
            ByteBuffer[] inputBuffers = encoder.getInputBuffers();
            ByteBuffer[] outputBuffers = encoder.getOutputBuffers();
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            
            int trackIndex = -1;
            boolean muxerStarted = false;
            
            // 编码每一帧
            for (int i = 0; i < frames.size(); i++) {
                Bitmap frame = frames.get(i);
                
                // 将Bitmap转换为YUV格式
                byte[] yuv = getNV21(frame);
                
                // 获取输入缓冲区
                int inputBufferIndex = encoder.dequeueInputBuffer(TIMEOUT_USEC);
                if (inputBufferIndex >= 0) {
                    ByteBuffer inputBuffer = inputBuffers[inputBufferIndex];
                    inputBuffer.clear();
                    inputBuffer.put(yuv);
                    
                    long presentationTimeUs = i * 1000000 / frameRate;
                    encoder.queueInputBuffer(inputBufferIndex, 0, yuv.length, presentationTimeUs, 0);
                }
                
                // 获取输出缓冲区
                int outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC);
                while (outputBufferIndex >= 0) {
                    ByteBuffer outputBuffer = outputBuffers[outputBufferIndex];
                    
                    if (!muxerStarted) {
                        // 添加轨道
                        MediaFormat newFormat = encoder.getOutputFormat();
                        trackIndex = muxer.addTrack(newFormat);
                        muxer.start();
                        muxerStarted = true;
                    }
                    
                    // 写入数据
                    if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        bufferInfo.size = 0;
                    }
                    
                    if (bufferInfo.size != 0) {
                        outputBuffer.position(bufferInfo.offset);
                        outputBuffer.limit(bufferInfo.offset + bufferInfo.size);
                        muxer.writeSampleData(trackIndex, outputBuffer, bufferInfo);
                    }
                    
                    encoder.releaseOutputBuffer(outputBufferIndex, false);
                    outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC);
                }
            }
            
            // 发送EOS
            int inputBufferIndex = encoder.dequeueInputBuffer(TIMEOUT_USEC);
            if (inputBufferIndex >= 0) {
                encoder.queueInputBuffer(inputBufferIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            }
            
            // 处理剩余的输出缓冲区
            int outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC);
            while (outputBufferIndex >= 0) {
                if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    break;
                }
                
                if (bufferInfo.size != 0) {
                    ByteBuffer outputBuffer = outputBuffers[outputBufferIndex];
                    outputBuffer.position(bufferInfo.offset);
                    outputBuffer.limit(bufferInfo.offset + bufferInfo.size);
                    muxer.writeSampleData(trackIndex, outputBuffer, bufferInfo);
                }
                
                encoder.releaseOutputBuffer(outputBufferIndex, false);
                outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC);
            }
            
            return true;
        } catch (IOException e) {
            Log.e(TAG, "视频编码失败: " + e.getMessage());
            return false;
        } finally {
            // 释放资源
            if (encoder != null) {
                encoder.stop();
                encoder.release();
            }
            if (muxer != null) {
                try {
                    muxer.stop();
                    muxer.release();
                } catch (Exception e) {
                    Log.e(TAG, "释放MediaMuxer失败: " + e.getMessage());
                }
            }
        }
    }
    
    /**
     * 将Bitmap转换为NV21格式
     */
    private static byte[] getNV21(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int frameSize = width * height;
        int[] argb = new int[frameSize];
        
        bitmap.getPixels(argb, 0, width, 0, 0, width, height);
        
        byte[] yuv = new byte[frameSize * 3 / 2];
        int yIndex = 0;
        int uvIndex = frameSize;
        
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                int rgb = argb[j * width + i];
                
                int r = (rgb >> 16) & 0xFF;
                int g = (rgb >> 8) & 0xFF;
                int b = rgb & 0xFF;
                
                int y = (66 * r + 129 * g + 25 * b + 128) >> 8 + 16;
                int u = (-38 * r - 74 * g + 112 * b + 128) >> 8 + 128;
                int v = (112 * r - 94 * g - 18 * b + 128) >> 8 + 128;
                
                y = Math.max(0, Math.min(255, y));
                u = Math.max(0, Math.min(255, u));
                v = Math.max(0, Math.min(255, v));
                
                yuv[yIndex++] = (byte) y;
                
                if (j % 2 == 0 && i % 2 == 0) {
                    yuv[uvIndex++] = (byte) v;
                    yuv[uvIndex++] = (byte) u;
                }
            }
        }
        
        return yuv;
    }
    
    /**
     * 分享视频
     */
    public static void shareVideo(Context context, String videoPath) {
        File videoFile = new File(videoPath);
        Uri videoUri = FileProvider.getUriForFile(
                context,
                context.getPackageName() + ".provider",
                videoFile
        );
        
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("video/*");
        shareIntent.putExtra(Intent.EXTRA_STREAM, videoUri);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        context.startActivity(Intent.createChooser(shareIntent, "分享视频"));
    }
    
    /**
     * 保存视频到相册
     */
    public static void saveVideoToGallery(Context context, String videoPath) {
        File videoFile = new File(videoPath);
        
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.TITLE, videoFile.getName());
        values.put(MediaStore.Video.Media.DISPLAY_NAME, videoFile.getName());
        values.put(MediaStore.Video.Media.DESCRIPTION, "由图生视频APP生成");
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000);
        values.put(MediaStore.Video.Media.DATE_TAKEN, System.currentTimeMillis());
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES);
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
        } else {
            values.put(MediaStore.Video.Media.DATA, videoPath);
        }
        
        Uri uri = context.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        
        if (uri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(MediaStore.Video.Media.IS_PENDING, 0);
            context.getContentResolver().update(uri, contentValues, null, null);
        }
    }
    
    // 特效应用方法
    
    /**
     * 应用淡入淡出特效
     */
    public static Bitmap applyFadeEffect(Bitmap bitmap, int frameIndex, int totalFrames) {
        Bitmap result = bitmap.copy(bitmap.getConfig(), true);
        Canvas canvas = new Canvas(result);
        Paint paint = new Paint();
        
        // 计算透明度
        int alpha;
        if (frameIndex < totalFrames / 4) {
            // 淡入
            alpha = 255 * frameIndex / (totalFrames / 4);
        } else if (frameIndex > totalFrames * 3 / 4) {
            // 淡出
            alpha = 255 * (totalFrames - frameIndex) / (totalFrames / 4);
        } else {
            // 中间部分保持不变
            alpha = 255;
        }
        
        paint.setAlpha(alpha);
        canvas.drawBitmap(bitmap, 0, 0, paint);
        
        return result;
    }
    
    /**
     * 应用缩放特效
     */
    public static Bitmap applyZoomEffect(Bitmap bitmap, int frameIndex, int totalFrames) {
        Bitmap result = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        Canvas canvas = new Canvas(result);
        
        // 计算缩放比例
        float scale;
        if (frameIndex < totalFrames / 2) {
            // 放大
            scale = 1.0f + 0.5f * frameIndex / (totalFrames / 2);
        } else {
            // 缩小
            scale = 1.5f - 0.5f * (frameIndex - totalFrames / 2) / (totalFrames / 2);
        }
        
        // 应用缩放
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale, bitmap.getWidth() / 2f, bitmap.getHeight() / 2f);
        
        Paint paint = new Paint();
        paint.setFilterBitmap(true);
        canvas.drawBitmap(bitmap, matrix, paint);
        
        return result;
    }
    
    /**
     * 应用旋转特效
     */
    public static Bitmap applyRotateEffect(Bitmap bitmap, int frameIndex, int totalFrames) {
        Bitmap result = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        Canvas canvas = new Canvas(result);
        
        // 计算旋转角度
        float angle = 360f * frameIndex / totalFrames;
        
        // 应用旋转
        Matrix matrix = new Matrix();
        matrix.postRotate(angle, bitmap.getWidth() / 2f, bitmap.getHeight() / 2f);
        
        Paint paint = new Paint();
        paint.setFilterBitmap(true);
        canvas.drawBitmap(bitmap, matrix, paint);
        
        return result;
    }
    
    /**
     * 应用波纹特效
     */
    public static Bitmap applyRippleEffect(Bitmap bitmap, int frameIndex, int totalFrames) {
        // 简化实现，实际应用中可以使用更复杂的波纹算法
        Bitmap result = bitmap.copy(bitmap.getConfig(), true);
        Canvas canvas = new Canvas(result);
        
        // 计算波纹参数
        float phase = (float) (2 * Math.PI * frameIndex / totalFrames);
        float amplitude = 10f;
        
        // 绘制波纹效果
        Paint paint = new Paint();
        paint.setColor(Color.argb(50, 255, 255, 255));
        
        for (int i = 0; i < 5; i++) {
            float radius = i * 20 + amplitude * (float) Math.sin(phase + i);
            canvas.drawCircle(bitmap.getWidth() / 2f, bitmap.getHeight() / 2f, radius, paint);
        }
        
        return result;
    }
    
    /**
     * 应用模糊特效
     */
    public static Bitmap applyBlurEffect(Bitmap bitmap, int frameIndex, int totalFrames) {
        // 计算模糊半径
        float radius = 25f * frameIndex / totalFrames;
        if (radius < 1) {
            radius = 1;
        }
        
        // 创建模糊效果
        Bitmap result = bitmap.copy(bitmap.getConfig(), true);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // 使用RenderEffect (Android 12+)
            RenderEffect blurEffect = RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.MIRROR);
            Canvas canvas = new Canvas(result);
            Paint paint = new Paint();
            paint.setColor(Color.TRANSPARENT);
            canvas.drawPaint(paint);
            
            // 这里简化处理，实际应用中需要更复杂的实现
            canvas.drawBitmap(bitmap, 0, 0, null);
        } else {
            // 使用RenderScript (兼容旧版本)
            RenderScript rs = RenderScript.create(null);
            Allocation input = Allocation.createFromBitmap(rs, bitmap);
            Allocation output = Allocation.createFromBitmap(rs, result);
            
            ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
            script.setInput(input);
            script.setRadius(radius);
            script.forEach(output);
            
            output.copyTo(result);
            rs.destroy();
        }
        
        return result;
    }
    
    /**
     * 应用黑白特效
     */
    public static Bitmap applyBWEffect(Bitmap bitmap) {
        Bitmap result = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        Canvas canvas = new Canvas(result);
        
        // 创建黑白效果的ColorMatrix
        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(0); // 设置饱和度为0，即黑白效果
        
        Paint paint = new Paint();
        paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        canvas.drawBitmap(bitmap, 0, 0, paint);
        
        return result;
    }
    
    /**
     * 应用复古特效
     */
    public static Bitmap applyVintageEffect(Bitmap bitmap) {
        Bitmap result = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        Canvas canvas = new Canvas(result);
        
        // 创建复古效果的ColorMatrix
        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(0.5f); // 降低饱和度
        
        // 调整颜色通道，增加黄褐色调
        ColorMatrix colorScale = new ColorMatrix();
        colorScale.setScale(1.3f, 1.1f, 0.8f, 1.0f); // 增加红色和绿色，减少蓝色
        
        colorMatrix.postConcat(colorScale);
        
        Paint paint = new Paint();
        paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        canvas.drawBitmap(bitmap, 0, 0, paint);
        
        // 添加噪点和划痕效果
        Paint noisePaint = new Paint();
        noisePaint.setColor(Color.argb(20, 200, 200, 200));
        
        for (int i = 0; i < 100; i++) {
            float x = (float) (Math.random() * bitmap.getWidth());
            float y = (float) (Math.random() * bitmap.getHeight());
            canvas.drawCircle(x, y, 1, noisePaint);
        }
        
        return result;
    }
}
