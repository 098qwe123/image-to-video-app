package com.example.imagetovideoapp.model;

/**
 * 特效模型类
 */
public class Effect {
    private String name;
    private int iconResourceId;
    private String description;
    private boolean isSelected;

    /**
     * 构造函数
     * 
     * @param name 特效名称
     * @param iconResourceId 特效图标资源ID
     * @param description 特效描述
     */
    public Effect(String name, int iconResourceId, String description) {
        this.name = name;
        this.iconResourceId = iconResourceId;
        this.description = description;
        this.isSelected = false;
    }

    // Getter和Setter方法
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIconResourceId() {
        return iconResourceId;
    }

    public void setIconResourceId(int iconResourceId) {
        this.iconResourceId = iconResourceId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
