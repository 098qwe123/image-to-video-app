package com.example.imagetovideoapp;

import android.app.Application;
import android.util.Log;

/**
 * 应用程序入口类，用于初始化全局资源和配置
 */
public class ImageToVideoApplication extends Application {
    private static final String TAG = "ImageToVideoApp";
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "应用程序启动");
        
        // 初始化全局配置
        initializeAppConfig();
        
        // 初始化AI模型资源
        initializeAIModels();
    }
    
    /**
     * 初始化应用程序配置
     */
    private void initializeAppConfig() {
        // 设置应用程序默认配置
        AppConfig.getInstance().setDefaultVideoResolution(720);
        AppConfig.getInstance().setDefaultVideoDuration(60);
        AppConfig.getInstance().setDefaultVideoFormat("mp4");
    }
    
    /**
     * 初始化AI模型资源
     */
    private void initializeAIModels() {
        // 这里将在实际开发中加载模型
        Log.d(TAG, "准备加载AI模型资源");
    }
    
    @Override
    public void onTerminate() {
        super.onTerminate();
        Log.d(TAG, "应用程序终止");
        
        // 释放资源
        releaseResources();
    }
    
    /**
     * 释放应用程序资源
     */
    private void releaseResources() {
        // 释放模型资源等
        Log.d(TAG, "释放应用资源");
    }
}
