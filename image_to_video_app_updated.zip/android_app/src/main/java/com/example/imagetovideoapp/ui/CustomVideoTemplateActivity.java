package com.example.imagetovideoapp.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.imagetovideoapp.R;
import com.example.imagetovideoapp.adapter.VideoTemplateAdapter;
import com.example.imagetovideoapp.model.VideoTemplate;
import com.example.imagetovideoapp.service.OfflineInferenceService;
import com.example.imagetovideoapp.utils.ImageUtils;
import com.example.imagetovideoapp.utils.VideoUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 用户自定义视频模板管理界面
 * 允许用户添加、预览和管理自定义视频模板
 */
public class CustomVideoTemplateActivity extends AppCompatActivity {
    private static final int REQUEST_VIDEO_PICK = 301;
    
    private RecyclerView templatesRecyclerView;
    private Button addVideoButton;
    private ProgressBar progressBar;
    private TextView statusTextView;
    
    private VideoTemplateAdapter adapter;
    private List<VideoTemplate> templates = new ArrayList<>();
    private OfflineInferenceService inferenceService;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_video_template);
        
        // 初始化视图
        initViews();
        
        // 初始化推理服务
        inferenceService = new OfflineInferenceService(this);
        inferenceService.initialize(new OfflineInferenceService.InitCallback() {
            @Override
            public void onSuccess() {
                statusTextView.setText("模型加载成功");
                progressBar.setVisibility(View.GONE);
            }
            
            @Override
            public void onFailure(String errorMessage) {
                statusTextView.setText("模型加载失败: " + errorMessage);
                progressBar.setVisibility(View.GONE);
            }
        });
        
        // 加载已保存的模板
        loadSavedTemplates();
    }
    
    /**
     * 初始化视图组件
     */
    private void initViews() {
        templatesRecyclerView = findViewById(R.id.templatesRecyclerView);
        addVideoButton = findViewById(R.id.addVideoButton);
        progressBar = findViewById(R.id.progressBar);
        statusTextView = findViewById(R.id.statusTextView);
        
        // 设置RecyclerView
        templatesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new VideoTemplateAdapter(this, templates);
        templatesRecyclerView.setAdapter(adapter);
        
        // 设置点击事件
        addVideoButton.setOnClickListener(v -> {
            openVideoGallery();
        });
        
        // 设置模板点击事件
        adapter.setOnItemClickListener(new VideoTemplateAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(VideoTemplate template) {
                // 返回选中的模板
                Intent resultIntent = new Intent();
                resultIntent.putExtra("templateId", template.getId());
                resultIntent.putExtra("templateName", template.getName());
                resultIntent.putExtra("templatePath", template.getVideoPath());
                setResult(RESULT_OK, resultIntent);
                finish();
            }
            
            @Override
            public void onDeleteClick(VideoTemplate template) {
                deleteTemplate(template);
            }
        });
    }
    
    /**
     * 加载已保存的模板
     */
    private void loadSavedTemplates() {
        // 显示加载状态
        progressBar.setVisibility(View.VISIBLE);
        statusTextView.setText("加载模板中...");
        
        // 从本地存储加载模板
        // 这里简化处理，实际应用中应该从数据库或文件系统加载
        templates.clear();
        
        // 添加内置模板
        templates.add(new VideoTemplate("1", "说话模板", "内置", R.drawable.template_talking));
        templates.add(new VideoTemplate("2", "旋转模板", "内置", R.drawable.template_rotating));
        templates.add(new VideoTemplate("3", "情感模板", "内置", R.drawable.template_emotion));
        
        // 加载用户自定义模板
        List<VideoTemplate> userTemplates = VideoUtils.loadUserTemplates(this);
        if (userTemplates != null) {
            templates.addAll(userTemplates);
        }
        
        // 更新UI
        adapter.notifyDataSetChanged();
        progressBar.setVisibility(View.GONE);
        statusTextView.setText("模板加载完成");
    }
    
    /**
     * 打开视频选择器
     */
    private void openVideoGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("video/*");
        startActivityForResult(intent, REQUEST_VIDEO_PICK);
    }
    
    /**
     * 处理选中的视频
     */
    private void processSelectedVideo(Uri videoUri) {
        // 显示处理状态
        progressBar.setVisibility(View.VISIBLE);
        statusTextView.setText("处理视频中...");
        
        // 在后台线程处理视频
        new Thread(() -> {
            try {
                // 获取视频信息
                String videoName = VideoUtils.getVideoName(this, videoUri);
                
                // 复制视频到应用私有存储
                String localPath = VideoUtils.copyVideoToLocal(this, videoUri);
                
                // 提取视频缩略图
                String thumbnailPath = VideoUtils.extractVideoThumbnail(this, videoUri);
                
                // 创建新模板
                String templateId = "user_" + System.currentTimeMillis();
                VideoTemplate newTemplate = new VideoTemplate(
                        templateId,
                        videoName,
                        localPath,
                        thumbnailPath
                );
                
                // 保存模板
                VideoUtils.saveUserTemplate(this, newTemplate);
                
                // 更新UI
                runOnUiThread(() -> {
                    templates.add(newTemplate);
                    adapter.notifyItemInserted(templates.size() - 1);
                    progressBar.setVisibility(View.GONE);
                    statusTextView.setText("视频模板添加成功");
                });
            } catch (Exception e) {
                e.printStackTrace();
                
                // 更新UI
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    statusTextView.setText("处理视频失败: " + e.getMessage());
                    Toast.makeText(CustomVideoTemplateActivity.this, 
                            "处理视频失败: " + e.getMessage(), 
                            Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }
    
    /**
     * 删除模板
     */
    private void deleteTemplate(VideoTemplate template) {
        // 只能删除用户自定义模板
        if (!template.getId().startsWith("user_")) {
            Toast.makeText(this, "内置模板不能删除", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // 显示处理状态
        progressBar.setVisibility(View.VISIBLE);
        statusTextView.setText("删除模板中...");
        
        // 在后台线程删除模板
        new Thread(() -> {
            try {
                // 删除模板文件
                VideoUtils.deleteUserTemplate(this, template);
                
                // 更新UI
                runOnUiThread(() -> {
                    int position = templates.indexOf(template);
                    if (position >= 0) {
                        templates.remove(position);
                        adapter.notifyItemRemoved(position);
                    }
                    progressBar.setVisibility(View.GONE);
                    statusTextView.setText("模板删除成功");
                });
            } catch (Exception e) {
                e.printStackTrace();
                
                // 更新UI
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    statusTextView.setText("删除模板失败: " + e.getMessage());
                    Toast.makeText(CustomVideoTemplateActivity.this, 
                            "删除模板失败: " + e.getMessage(), 
                            Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (resultCode == RESULT_OK && requestCode == REQUEST_VIDEO_PICK && data != null) {
            Uri videoUri = data.getData();
            processSelectedVideo(videoUri);
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        // 释放资源
        if (inferenceService != null) {
            inferenceService.release();
        }
    }
}
