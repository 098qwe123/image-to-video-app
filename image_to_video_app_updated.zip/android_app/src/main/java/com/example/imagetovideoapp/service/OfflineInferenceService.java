package com.example.imagetovideoapp.service;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.example.imagetovideoapp.model.LivePortraitModel;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 离线推理服务类
 * 负责管理模型加载和推理过程，确保所有AI处理在本地完成
 */
public class OfflineInferenceService {
    private static final String TAG = "OfflineInferenceService";
    
    private Context context;
    private ModelManagerService modelManager;
    private LivePortraitModel model;
    private ExecutorService executor;
    private Handler mainHandler;
    private boolean isModelLoaded = false;
    
    /**
     * 构造函数
     * @param context 应用上下文
     */
    public OfflineInferenceService(Context context) {
        this.context = context;
        this.modelManager = new ModelManagerService(context);
        this.executor = Executors.newSingleThreadExecutor();
        this.mainHandler = new Handler(Looper.getMainLooper());
    }
    
    /**
     * 初始化服务
     * @param callback 初始化完成回调
     */
    public void initialize(InitCallback callback) {
        executor.execute(() -> {
            try {
                // 初始化模型文件
                boolean modelInitialized = modelManager.initializeModels();
                if (!modelInitialized) {
                    mainHandler.post(() -> callback.onFailure("模型文件初始化失败"));
                    return;
                }
                
                // 加载模型
                model = new LivePortraitModel(context);
                isModelLoaded = model.isInitialized();
                
                if (isModelLoaded) {
                    mainHandler.post(() -> callback.onSuccess());
                } else {
                    mainHandler.post(() -> callback.onFailure("模型加载失败"));
                }
            } catch (Exception e) {
                Log.e(TAG, "初始化失败: " + e.getMessage());
                mainHandler.post(() -> callback.onFailure("初始化失败: " + e.getMessage()));
            }
        });
    }
    
    /**
     * 生成单帧
     * @param sourceImage 源图像
     * @param drivingImage 驱动图像
     * @param callback 生成完成回调
     */
    public void generateFrame(Bitmap sourceImage, Bitmap drivingImage, FrameCallback callback) {
        if (!isModelLoaded) {
            callback.onFailure("模型未加载");
            return;
        }
        
        executor.execute(() -> {
            try {
                Bitmap result = model.generateFrame(sourceImage, drivingImage);
                
                if (result != null) {
                    mainHandler.post(() -> callback.onSuccess(result));
                } else {
                    mainHandler.post(() -> callback.onFailure("生成帧失败"));
                }
            } catch (Exception e) {
                Log.e(TAG, "生成帧失败: " + e.getMessage());
                mainHandler.post(() -> callback.onFailure("生成帧失败: " + e.getMessage()));
            }
        });
    }
    
    /**
     * 批量生成帧
     * @param sourceImage 源图像
     * @param drivingImages 驱动图像列表
     * @param callback 生成完成回调
     */
    public void generateFrames(Bitmap sourceImage, Bitmap[] drivingImages, FramesCallback callback) {
        if (!isModelLoaded) {
            callback.onFailure("模型未加载");
            return;
        }
        
        executor.execute(() -> {
            try {
                int totalFrames = drivingImages.length;
                Bitmap[] results = new Bitmap[totalFrames];
                
                for (int i = 0; i < totalFrames; i++) {
                    // 生成帧
                    Bitmap result = model.generateFrame(sourceImage, drivingImages[i]);
                    results[i] = result;
                    
                    // 报告进度
                    final int progress = (i + 1) * 100 / totalFrames;
                    final int frameIndex = i;
                    mainHandler.post(() -> callback.onProgress(progress, frameIndex));
                }
                
                mainHandler.post(() -> callback.onSuccess(results));
            } catch (Exception e) {
                Log.e(TAG, "批量生成帧失败: " + e.getMessage());
                mainHandler.post(() -> callback.onFailure("批量生成帧失败: " + e.getMessage()));
            }
        });
    }
    
    /**
     * 检查模型是否已加载
     * @return 模型是否已加载
     */
    public boolean isModelLoaded() {
        return isModelLoaded;
    }
    
    /**
     * 释放资源
     */
    public void release() {
        if (model != null) {
            model.close();
            isModelLoaded = false;
        }
        
        executor.shutdown();
    }
    
    /**
     * 初始化回调接口
     */
    public interface InitCallback {
        void onSuccess();
        void onFailure(String errorMessage);
    }
    
    /**
     * 单帧生成回调接口
     */
    public interface FrameCallback {
        void onSuccess(Bitmap frame);
        void onFailure(String errorMessage);
    }
    
    /**
     * 批量帧生成回调接口
     */
    public interface FramesCallback {
        void onProgress(int progress, int frameIndex);
        void onSuccess(Bitmap[] frames);
        void onFailure(String errorMessage);
    }
}
