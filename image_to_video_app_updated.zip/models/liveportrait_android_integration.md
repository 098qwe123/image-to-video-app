# LivePortrait模型Android端适配方案

## 1. 概述

本文档详细描述了将LivePortrait图生视频模型适配到Android平台的技术方案，包括模型导出、优化、量化以及Android端集成的具体步骤。

## 2. 技术路线

我们选择的技术路线是：**LivePortrait模型 → ONNX格式 → Android ONNX Runtime**

这一路线的优势在于：
- ONNX是开放的模型交换格式，兼容性好
- ONNX Runtime在Android平台上性能优秀
- 支持模型量化和优化，适合移动端部署
- 开发流程成熟，社区支持丰富

## 3. 模型准备流程

### 3.1 环境准备

```bash
# 创建Python环境
conda create -n liveportrait-export python=3.10
conda activate liveportrait-export

# 安装必要的依赖
pip install torch torchvision onnx onnxruntime
pip install numpy opencv-python pillow
```

### 3.2 获取LivePortrait模型

```bash
# 克隆LivePortrait代码库
git clone https://github.com/KwaiVGI/LivePortrait
cd LivePortrait

# 下载预训练权重
pip install -U "huggingface_hub[cli]"
huggingface-cli download KwaiVGI/LivePortrait --local-dir pretrained_weights --exclude "*.git*" "README.md" "docs"
```

### 3.3 模型导出为ONNX格式

创建一个导出脚本`export_to_onnx.py`：

```python
import torch
import torch.nn as nn
import os
import sys
from src.models.keypoint_detector import KPDetector
from src.models.generator import OcclusionAwareGenerator
import argparse

def load_checkpoints(checkpoint_path, cpu=False):
    if cpu:
        checkpoint = torch.load(checkpoint_path, map_location=torch.device('cpu'))
    else:
        checkpoint = torch.load(checkpoint_path)
    
    generator = OcclusionAwareGenerator(**checkpoint['generator_params'])
    generator.load_state_dict(checkpoint['generator'])
    
    kp_detector = KPDetector(**checkpoint['kp_detector_params'])
    kp_detector.load_state_dict(checkpoint['kp_detector'])
    
    if not cpu:
        generator = generator.cuda()
        kp_detector = kp_detector.cuda()
    
    generator.eval()
    kp_detector.eval()
    
    return generator, kp_detector

def export_to_onnx(checkpoint_path, output_dir, img_size=256):
    # 加载模型
    generator, kp_detector = load_checkpoints(checkpoint_path, cpu=True)
    
    # 准备输入
    source = torch.randn(1, 3, img_size, img_size)
    driving = torch.randn(1, 3, img_size, img_size)
    
    # 导出关键点检测器
    kp_source = kp_detector(source)
    kp_driving = kp_detector(driving)
    
    # 简化模型输入输出
    class KPDetectorWrapper(nn.Module):
        def __init__(self, model):
            super().__init__()
            self.model = model
            
        def forward(self, x):
            out = self.model(x)
            return out['value'], out['jacobian']
    
    kp_detector_wrapped = KPDetectorWrapper(kp_detector)
    
    # 导出关键点检测器
    torch.onnx.export(
        kp_detector_wrapped,
        source,
        os.path.join(output_dir, "kp_detector.onnx"),
        export_params=True,
        opset_version=12,
        do_constant_folding=True,
        input_names=['source'],
        output_names=['keypoints', 'jacobian'],
        dynamic_axes={
            'source': {0: 'batch_size'},
            'keypoints': {0: 'batch_size'},
            'jacobian': {0: 'batch_size'}
        }
    )
    
    # 简化生成器模型
    class GeneratorWrapper(nn.Module):
        def __init__(self, model):
            super().__init__()
            self.model = model
            
        def forward(self, source_image, kp_source_value, kp_source_jacobian, 
                   kp_driving_value, kp_driving_jacobian):
            kp_source = {'value': kp_source_value, 'jacobian': kp_source_jacobian}
            kp_driving = {'value': kp_driving_value, 'jacobian': kp_driving_jacobian}
            out = self.model(source_image, kp_source=kp_source, kp_driving=kp_driving)
            return out['prediction']
    
    generator_wrapped = GeneratorWrapper(generator)
    
    # 准备生成器输入
    kp_source_value, kp_source_jacobian = kp_source['value'], kp_source['jacobian']
    kp_driving_value, kp_driving_jacobian = kp_driving['value'], kp_driving['jacobian']
    
    # 导出生成器
    torch.onnx.export(
        generator_wrapped,
        (source, kp_source_value, kp_source_jacobian, kp_driving_value, kp_driving_jacobian),
        os.path.join(output_dir, "generator.onnx"),
        export_params=True,
        opset_version=12,
        do_constant_folding=True,
        input_names=['source_image', 'kp_source_value', 'kp_source_jacobian', 
                    'kp_driving_value', 'kp_driving_jacobian'],
        output_names=['prediction'],
        dynamic_axes={
            'source_image': {0: 'batch_size'},
            'kp_source_value': {0: 'batch_size'},
            'kp_source_jacobian': {0: 'batch_size'},
            'kp_driving_value': {0: 'batch_size'},
            'kp_driving_jacobian': {0: 'batch_size'},
            'prediction': {0: 'batch_size'}
        }
    )
    
    print(f"模型已成功导出到 {output_dir}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", default="pretrained_weights/humans.pth", help="模型检查点路径")
    parser.add_argument("--output_dir", default="onnx_models", help="ONNX模型输出目录")
    parser.add_argument("--img_size", type=int, default=256, help="输入图像大小")
    
    args = parser.parse_args()
    
    os.makedirs(args.output_dir, exist_ok=True)
    export_to_onnx(args.checkpoint, args.output_dir, args.img_size)
```

执行导出脚本：

```bash
python export_to_onnx.py
```

### 3.4 ONNX模型优化与量化

创建模型优化脚本`optimize_onnx.py`：

```python
import onnx
from onnxruntime.quantization import quantize_dynamic, QuantType
import argparse
import os

def optimize_onnx_model(model_path, output_path):
    # 加载模型
    model = onnx.load(model_path)
    
    # 检查模型有效性
    onnx.checker.check_model(model)
    
    # 优化模型
    optimized_model = onnx.optimizer.optimize(model, ['fuse_bn_into_conv', 'eliminate_unused_initializer'])
    
    # 保存优化后的模型
    onnx.save(optimized_model, output_path)
    print(f"优化后的模型已保存到 {output_path}")

def quantize_onnx_model(model_path, output_path):
    # 动态量化模型
    quantize_dynamic(
        model_input=model_path,
        model_output=output_path,
        weight_type=QuantType.QUInt8
    )
    print(f"量化后的模型已保存到 {output_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_dir", default="onnx_models", help="ONNX模型目录")
    parser.add_argument("--output_dir", default="onnx_models_optimized", help="优化后模型输出目录")
    
    args = parser.parse_args()
    
    os.makedirs(args.output_dir, exist_ok=True)
    
    # 优化并量化关键点检测器
    kp_detector_path = os.path.join(args.model_dir, "kp_detector.onnx")
    kp_detector_optimized_path = os.path.join(args.output_dir, "kp_detector_optimized.onnx")
    kp_detector_quantized_path = os.path.join(args.output_dir, "kp_detector_quantized.onnx")
    
    optimize_onnx_model(kp_detector_path, kp_detector_optimized_path)
    quantize_onnx_model(kp_detector_optimized_path, kp_detector_quantized_path)
    
    # 优化并量化生成器
    generator_path = os.path.join(args.model_dir, "generator.onnx")
    generator_optimized_path = os.path.join(args.output_dir, "generator_optimized.onnx")
    generator_quantized_path = os.path.join(args.output_dir, "generator_quantized.onnx")
    
    optimize_onnx_model(generator_path, generator_optimized_path)
    quantize_onnx_model(generator_optimized_path, generator_quantized_path)
```

执行优化脚本：

```bash
python optimize_onnx.py
```

### 3.5 验证ONNX模型

创建验证脚本`validate_onnx.py`：

```python
import onnxruntime as ort
import numpy as np
import cv2
import torch
import os
import argparse
from PIL import Image

def preprocess_image(image_path, size=256):
    img = Image.open(image_path).convert('RGB')
    img = img.resize((size, size))
    img = np.array(img).astype(np.float32) / 255.0
    img = img.transpose((2, 0, 1))
    img = np.expand_dims(img, axis=0)
    return img

def validate_onnx_models(kp_detector_path, generator_path, source_image_path, driving_image_path):
    # 加载ONNX运行时会话
    kp_detector_session = ort.InferenceSession(kp_detector_path)
    generator_session = ort.InferenceSession(generator_path)
    
    # 预处理图像
    source_img = preprocess_image(source_image_path)
    driving_img = preprocess_image(driving_image_path)
    
    # 运行关键点检测器
    kp_source_value, kp_source_jacobian = kp_detector_session.run(
        None, {'source': source_img.astype(np.float32)}
    )
    
    kp_driving_value, kp_driving_jacobian = kp_detector_session.run(
        None, {'source': driving_img.astype(np.float32)}
    )
    
    # 运行生成器
    prediction = generator_session.run(
        None, {
            'source_image': source_img.astype(np.float32),
            'kp_source_value': kp_source_value,
            'kp_source_jacobian': kp_source_jacobian,
            'kp_driving_value': kp_driving_value,
            'kp_driving_jacobian': kp_driving_jacobian
        }
    )[0]
    
    # 后处理输出
    output_img = prediction[0].transpose(1, 2, 0)
    output_img = (output_img * 255).astype(np.uint8)
    
    # 保存结果
    cv2.imwrite('onnx_result.jpg', cv2.cvtColor(output_img, cv2.COLOR_RGB2BGR))
    print("验证完成，结果已保存为 onnx_result.jpg")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--kp_detector", default="onnx_models_optimized/kp_detector_quantized.onnx", help="关键点检测器路径")
    parser.add_argument("--generator", default="onnx_models_optimized/generator_quantized.onnx", help="生成器路径")
    parser.add_argument("--source", default="assets/examples/source/s6.jpg", help="源图像路径")
    parser.add_argument("--driving", default="assets/examples/driving/d0.jpg", help="驱动图像路径")
    
    args = parser.parse_args()
    
    validate_onnx_models(args.kp_detector, args.generator, args.source, args.driving)
```

执行验证脚本：

```bash
python validate_onnx.py
```

## 4. Android端集成方案

### 4.1 项目配置

在Android项目的`build.gradle`文件中添加ONNX Runtime依赖：

```gradle
dependencies {
    // ONNX Runtime
    implementation 'com.microsoft.onnxruntime:onnxruntime-android:1.15.1'
    
    // 图像处理
    implementation 'androidx.camera:camera-camera2:1.3.0'
    implementation 'androidx.camera:camera-lifecycle:1.3.0'
    implementation 'androidx.camera:camera-view:1.3.0'
}
```

### 4.2 模型加载与推理类

创建`LivePortraitModel.java`类：

```java
package com.example.imagetovideoapp.model;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtException;
import ai.onnxruntime.OrtSession;

public class LivePortraitModel {
    private static final String TAG = "LivePortraitModel";
    private static final int IMAGE_SIZE = 256;
    
    private Context context;
    private OrtEnvironment ortEnvironment;
    private OrtSession kpDetectorSession;
    private OrtSession generatorSession;
    
    public LivePortraitModel(Context context) {
        this.context = context;
        try {
            // 初始化ONNX Runtime环境
            ortEnvironment = OrtEnvironment.getEnvironment();
            
            // 加载关键点检测器模型
            InputStream kpDetectorInputStream = context.getAssets().open("kp_detector_quantized.onnx");
            byte[] kpDetectorBytes = new byte[kpDetectorInputStream.available()];
            kpDetectorInputStream.read(kpDetectorBytes);
            kpDetectorInputStream.close();
            
            kpDetectorSession = ortEnvironment.createSession(kpDetectorBytes);
            
            // 加载生成器模型
            InputStream generatorInputStream = context.getAssets().open("generator_quantized.onnx");
            byte[] generatorBytes = new byte[generatorInputStream.available()];
            generatorInputStream.read(generatorBytes);
            generatorInputStream.close();
            
            generatorSession = ortEnvironment.createSession(generatorBytes);
            
            Log.d(TAG, "模型加载成功");
        } catch (IOException | OrtException e) {
            Log.e(TAG, "模型加载失败", e);
        }
    }
    
    // 预处理图像
    private float[][][][] preprocessImage(Bitmap bitmap) {
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, IMAGE_SIZE, IMAGE_SIZE, true);
        
        float[][][][] inputTensor = new float[1][3][IMAGE_SIZE][IMAGE_SIZE];
        int[] pixels = new int[IMAGE_SIZE * IMAGE_SIZE];
        resizedBitmap.getPixels(pixels, 0, IMAGE_SIZE, 0, 0, IMAGE_SIZE, IMAGE_SIZE);
        
        for (int y = 0; y < IMAGE_SIZE; y++) {
            for (int x = 0; x < IMAGE_SIZE; x++) {
                int pixel = pixels[y * IMAGE_SIZE + x];
                
                // 归一化到[0,1]
                inputTensor[0][0][y][x] = ((pixel >> 16) & 0xFF) / 255.0f; // R
                inputTensor[0][1][y][x] = ((pixel >> 8) & 0xFF) / 255.0f;  // G
                inputTensor[0][2][y][x] = (pixel & 0xFF) / 255.0f;         // B
            }
        }
        
        return inputTensor;
    }
    
    // 执行关键点检测
    private Map<String, OnnxTensor> detectKeypoints(Bitmap image) throws OrtException {
        float[][][][] preprocessedImage = preprocessImage(image);
        
        // 创建输入张量
        OnnxTensor imageTensor = OnnxTensor.createTensor(
                ortEnvironment, 
                FloatBuffer.wrap(flatten(preprocessedImage)), 
                new long[]{1, 3, IMAGE_SIZE, IMAGE_SIZE}
        );
        
        // 准备输入映射
        Map<String, OnnxTensor> inputs = new HashMap<>();
        inputs.put("source", imageTensor);
        
        // 运行模型
        OrtSession.Result result = kpDetectorSession.run(inputs);
        
        // 获取输出
        OnnxTensor keypointsTensor = (OnnxTensor) result.get(0);
        OnnxTensor jacobianTensor = (OnnxTensor) result.get(1);
        
        Map<String, OnnxTensor> outputs = new HashMap<>();
        outputs.put("keypoints", keypointsTensor);
        outputs.put("jacobian", jacobianTensor);
        
        return outputs;
    }
    
    // 生成动画帧
    public Bitmap generateFrame(Bitmap sourceImage, Bitmap drivingImage) {
        try {
            // 检测关键点
            Map<String, OnnxTensor> sourceKeypoints = detectKeypoints(sourceImage);
            Map<String, OnnxTensor> drivingKeypoints = detectKeypoints(drivingImage);
            
            // 准备生成器输入
            float[][][][] preprocessedSourceImage = preprocessImage(sourceImage);
            OnnxTensor sourceTensor = OnnxTensor.createTensor(
                    ortEnvironment, 
                    FloatBuffer.wrap(flatten(preprocessedSourceImage)), 
                    new long[]{1, 3, IMAGE_SIZE, IMAGE_SIZE}
            );
            
            // 准备输入映射
            Map<String, OnnxTensor> inputs = new HashMap<>();
            inputs.put("source_image", sourceTensor);
            inputs.put("kp_source_value", sourceKeypoints.get("keypoints"));
            inputs.put("kp_source_jacobian", sourceKeypoints.get("jacobian"));
            inputs.put("kp_driving_value", drivingKeypoints.get("keypoints"));
            inputs.put("kp_driving_jacobian", drivingKeypoints.get("jacobian"));
            
            // 运行生成器
            OrtSession.Result result = generatorSession.run(inputs);
            
            // 获取输出
            OnnxTensor predictionTensor = (OnnxTensor) result.get(0);
            float[][][][] prediction = (float[][][][]) predictionTensor.getValue();
            
            // 后处理输出
            Bitmap outputBitmap = Bitmap.createBitmap(IMAGE_SIZE, IMAGE_SIZE, Bitmap.Config.ARGB_8888);
            int[] outputPixels = new int[IMAGE_SIZE * IMAGE_SIZE];
            
            for (int y = 0; y < IMAGE_SIZE; y++) {
                for (int x = 0; x < IMAGE_SIZE; x++) {
                    int r = (int) (prediction[0][0][y][x] * 255);
                    int g = (int) (prediction[0][1][y][x] * 255);
                    int b = (int) (prediction[0][2][y][x] * 255);
                    
                    r = Math.max(0, Math.min(255, r));
                    g = Math.max(0, Math.min(255, g));
                    b = Math.max(0, Math.min(255, b));
                    
                    outputPixels[y * IMAGE_SIZE + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
                }
            }
            
            outputBitmap.setPixels(outputPixels, 0, IMAGE_SIZE, 0, 0, IMAGE_SIZE, IMAGE_SIZE);
            
            // 释放资源
            sourceTensor.close();
            sourceKeypoints.get("keypoints").close();
            sourceKeypoints.get("jacobian").close();
            drivingKeypoints.get("keypoints").close();
            drivingKeypoints.get("jacobian").close();
            predictionTensor.close();
            
            return outputBitmap;
        } catch (OrtException e) {
            Log.e(TAG, "生成帧失败", e);
            return null;
        }
    }
    
    // 辅助方法：将多维数组展平为一维数组
    private float[] flatten(float[][][][] array) {
        int size = array.length * array[0].length * array[0][0].length * array[0][0][0].length;
        float[] flatArray = new float[size];
        
        int index = 0;
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                for (int k = 0; k < array[i][j].length; k++) {
                    for (int l = 0; l < array[i][j][k].length; l++) {
                        flatArray[index++] = array[i][j][k][l];
                    }
                }
            }
        }
        
        return flatArray;
    }
    
    // 释放资源
    public void close() {
        try {
            if (kpDetectorSession != null) {
                kpDetectorSession.close();
            }
            if (generatorSession != null) {
                generatorSession.close();
            }
            if (ortEnvironment != null) {
                ortEnvironment.close();
            }
        } catch (OrtException e) {
            Log.e(TAG, "关闭模型失败", e);
        }
    }
}
```

### 4.3 视频生成服务类

创建`VideoGenerationService.java`类：

```java
package com.example.imagetovideoapp.service;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.util.Log;

import com.example.imagetovideoapp.model.LivePortraitModel;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class VideoGenerationService {
    private static final String TAG = "VideoGenerationService";
    private static final int FRAME_RATE = 30;
    private static final int IFRAME_INTERVAL = 1;
    private static final int TIMEOUT_USEC = 10000;
    
    private Context context;
    private LivePortraitModel model;
    private Executor executor;
    
    public VideoGenerationService(Context context) {
        this.context = context;
        this.model = new LivePortraitModel(context);
        this.executor = Executors.newSingleThreadExecutor();
    }
    
    public interface GenerationCallback {
        void onProgress(int progress, int total);
        void onComplete(String outputPath);
        void onError(String message);
    }
    
    public void generateVideo(Bitmap sourceImage, List<Bitmap> drivingFrames, String outputPath, GenerationCallback callback) {
        executor.execute(() -> {
            try {
                // 生成所有帧
                List<Bitmap> generatedFrames = new ArrayList<>();
                int totalFrames = drivingFrames.size();
                
                for (int i = 0; i < totalFrames; i++) {
                    Bitmap drivingFrame = drivingFrames.get(i);
                    Bitmap generatedFrame = model.generateFrame(sourceImage, drivingFrame);
                    generatedFrames.add(generatedFrame);
                    
                    // 报告进度
                    int finalI = i;
                    callback.onProgress(finalI + 1, totalFrames);
                }
                
                // 将帧编码为视频
                encodeFramesToVideo(generatedFrames, outputPath, callback);
            } catch (Exception e) {
                Log.e(TAG, "视频生成失败", e);
                callback.onError("视频生成失败: " + e.getMessage());
            }
        });
    }
    
    private void encodeFramesToVideo(List<Bitmap> frames, String outputPath, GenerationCallback callback) {
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        
        try {
            // 获取第一帧的尺寸
            Bitmap firstFrame = frames.get(0);
            int width = firstFrame.getWidth();
            int height = firstFrame.getHeight();
            
            // 配置视频编码器
            MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            format.setInteger(MediaFormat.KEY_BIT_RATE, width * height * 4);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, FRAME_RATE);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, IFRAME_INTERVAL);
            
            // 创建编码器
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();
            
            // 创建媒体混合器
            muxer = new MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            
            ByteBuffer[] inputBuffers = encoder.getInputBuffers();
            ByteBuffer[] outputBuffers = encoder.getOutputBuffers();
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            
            int trackIndex = -1;
            boolean muxerStarted = false;
            
            // 编码每一帧
            for (int i = 0; i < frames.size(); i++) {
                Bitmap frame = frames.get(i);
                
                // 将Bitmap转换为YUV格式
                byte[] yuv = getNV21(frame);
                
                // 获取输入缓冲区
                int inputBufferIndex = encoder.dequeueInputBuffer(TIMEOUT_USEC);
                if (inputBufferIndex >= 0) {
                    ByteBuffer inputBuffer = inputBuffers[inputBufferIndex];
                    inputBuffer.clear();
                    inputBuffer.put(yuv);
                    
                    long presentationTimeUs = i * 1000000 / FRAME_RATE;
                    encoder.queueInputBuffer(inputBufferIndex, 0, yuv.length, presentationTimeUs, 0);
                }
                
                // 获取输出缓冲区
                int outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC);
                while (outputBufferIndex >= 0) {
                    ByteBuffer outputBuffer = outputBuffers[outputBufferIndex];
                    
                    if (!muxerStarted) {
                        // 添加轨道
                        MediaFormat newFormat = encoder.getOutputFormat();
                        trackIndex = muxer.addTrack(newFormat);
                        muxer.start();
                        muxerStarted = true;
                    }
                    
                    // 写入数据
                    if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        bufferInfo.size = 0;
                    }
                    
                    if (bufferInfo.size != 0) {
                        outputBuffer.position(bufferInfo.offset);
                        outputBuffer.limit(bufferInfo.offset + bufferInfo.size);
                        muxer.writeSampleData(trackIndex, outputBuffer, bufferInfo);
                    }
                    
                    encoder.releaseOutputBuffer(outputBufferIndex, false);
                    outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC);
                }
            }
            
            // 发送EOS
            int inputBufferIndex = encoder.dequeueInputBuffer(TIMEOUT_USEC);
            if (inputBufferIndex >= 0) {
                encoder.queueInputBuffer(inputBufferIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            }
            
            // 处理剩余的输出缓冲区
            int outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC);
            while (outputBufferIndex >= 0) {
                if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    break;
                }
                
                if (bufferInfo.size != 0) {
                    ByteBuffer outputBuffer = outputBuffers[outputBufferIndex];
                    outputBuffer.position(bufferInfo.offset);
                    outputBuffer.limit(bufferInfo.offset + bufferInfo.size);
                    muxer.writeSampleData(trackIndex, outputBuffer, bufferInfo);
                }
                
                encoder.releaseOutputBuffer(outputBufferIndex, false);
                outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC);
            }
            
            // 完成
            callback.onComplete(outputPath);
        } catch (IOException e) {
            Log.e(TAG, "视频编码失败", e);
            callback.onError("视频编码失败: " + e.getMessage());
        } finally {
            // 释放资源
            if (encoder != null) {
                encoder.stop();
                encoder.release();
            }
            if (muxer != null) {
                muxer.stop();
                muxer.release();
            }
        }
    }
    
    // 将Bitmap转换为NV21格式
    private byte[] getNV21(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int frameSize = width * height;
        int[] argb = new int[frameSize];
        
        bitmap.getPixels(argb, 0, width, 0, 0, width, height);
        
        byte[] yuv = new byte[frameSize * 3 / 2];
        int yIndex = 0;
        int uvIndex = frameSize;
        
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                int rgb = argb[j * width + i];
                
                int r = (rgb >> 16) & 0xFF;
                int g = (rgb >> 8) & 0xFF;
                int b = rgb & 0xFF;
                
                int y = (66 * r + 129 * g + 25 * b + 128) >> 8 + 16;
                int u = (-38 * r - 74 * g + 112 * b + 128) >> 8 + 128;
                int v = (112 * r - 94 * g - 18 * b + 128) >> 8 + 128;
                
                y = Math.max(0, Math.min(255, y));
                u = Math.max(0, Math.min(255, u));
                v = Math.max(0, Math.min(255, v));
                
                yuv[yIndex++] = (byte) y;
                
                if (j % 2 == 0 && i % 2 == 0) {
                    yuv[uvIndex++] = (byte) v;
                    yuv[uvIndex++] = (byte) u;
                }
            }
        }
        
        return yuv;
    }
    
    // 释放资源
    public void release() {
        model.close();
    }
}
```

### 4.4 使用示例

在Activity中使用模型：

```java
package com.example.imagetovideoapp.ui;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.imagetovideoapp.R;
import com.example.imagetovideoapp.service.VideoGenerationService;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class VideoGenerationActivity extends AppCompatActivity {
    private ImageView sourceImageView;
    private Button generateButton;
    private ProgressBar progressBar;
    private TextView progressText;
    
    private VideoGenerationService videoService;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_generation);
        
        // 初始化视图
        sourceImageView = findViewById(R.id.sourceImageView);
        generateButton = findViewById(R.id.generateButton);
        progressBar = findViewById(R.id.progressBar);
        progressText = findViewById(R.id.progressText);
        
        // 初始化服务
        videoService = new VideoGenerationService(this);
        
        // 加载示例图像
        try {
            InputStream is = getAssets().open("example_source.jpg");
            Bitmap sourceBitmap = BitmapFactory.decodeStream(is);
            sourceImageView.setImageBitmap(sourceBitmap);
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // 设置生成按钮点击事件
        generateButton.setOnClickListener(v -> {
            generateVideo();
        });
    }
    
    private void generateVideo() {
        // 显示进度条
        progressBar.setVisibility(View.VISIBLE);
        progressText.setVisibility(View.VISIBLE);
        generateButton.setEnabled(false);
        
        try {
            // 加载源图像
            InputStream sourceIs = getAssets().open("example_source.jpg");
            Bitmap sourceBitmap = BitmapFactory.decodeStream(sourceIs);
            sourceIs.close();
            
            // 加载驱动帧
            List<Bitmap> drivingFrames = new ArrayList<>();
            for (int i = 1; i <= 30; i++) {
                InputStream frameIs = getAssets().open("driving_frames/frame_" + i + ".jpg");
                Bitmap frameBitmap = BitmapFactory.decodeStream(frameIs);
                drivingFrames.add(frameBitmap);
                frameIs.close();
            }
            
            // 设置输出路径
            File outputFile = new File(getExternalFilesDir(null), "generated_video.mp4");
            String outputPath = outputFile.getAbsolutePath();
            
            // 生成视频
            videoService.generateVideo(sourceBitmap, drivingFrames, outputPath, new VideoGenerationService.GenerationCallback() {
                @Override
                public void onProgress(int progress, int total) {
                    runOnUiThread(() -> {
                        int percentage = (int) ((float) progress / total * 100);
                        progressBar.setProgress(percentage);
                        progressText.setText(percentage + "%");
                    });
                }
                
                @Override
                public void onComplete(String outputPath) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        progressText.setVisibility(View.GONE);
                        generateButton.setEnabled(true);
                        
                        Toast.makeText(VideoGenerationActivity.this, 
                                "视频生成成功: " + outputPath, 
                                Toast.LENGTH_LONG).show();
                        
                        // 这里可以添加播放视频的代码
                    });
                }
                
                @Override
                public void onError(String message) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        progressText.setVisibility(View.GONE);
                        generateButton.setEnabled(true);
                        
                        Toast.makeText(VideoGenerationActivity.this, 
                                "错误: " + message, 
                                Toast.LENGTH_LONG).show();
                    });
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
            progressBar.setVisibility(View.GONE);
            progressText.setVisibility(View.GONE);
            generateButton.setEnabled(true);
            
            Toast.makeText(this, "加载资源失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        videoService.release();
    }
}
```

## 5. 性能优化策略

### 5.1 模型优化

1. **模型量化**：将模型权重从FP32降至INT8，减小模型大小和计算量
2. **模型剪枝**：移除模型中不重要的连接，减小模型大小
3. **低精度推理**：使用FP16进行计算，提高推理速度

### 5.2 推理优化

1. **批处理**：一次处理多个帧，减少模型加载和初始化开销
2. **异步处理**：将推理过程放入后台线程，避免阻塞UI
3. **缓存机制**：缓存中间结果，避免重复计算

### 5.3 内存优化

1. **图像采样**：根据设备内存调整图像加载分辨率
2. **内存缓存**：优化图像和视频帧的缓存策略
3. **资源回收**：及时释放不需要的资源

## 6. 测试与验证

### 6.1 单元测试

创建`LivePortraitModelTest.java`：

```java
package com.example.imagetovideoapp.model;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.io.InputStream;

import static org.junit.Assert.assertNotNull;

@RunWith(AndroidJUnit4.class)
public class LivePortraitModelTest {
    private Context context;
    private LivePortraitModel model;
    
    @Before
    public void setUp() {
        context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        model = new LivePortraitModel(context);
    }
    
    @Test
    public void testGenerateFrame() throws IOException {
        // 加载测试图像
        InputStream sourceIs = context.getAssets().open("test_source.jpg");
        Bitmap sourceBitmap = BitmapFactory.decodeStream(sourceIs);
        sourceIs.close();
        
        InputStream drivingIs = context.getAssets().open("test_driving.jpg");
        Bitmap drivingBitmap = BitmapFactory.decodeStream(drivingIs);
        drivingIs.close();
        
        // 生成帧
        Bitmap result = model.generateFrame(sourceBitmap, drivingBitmap);
        
        // 验证结果
        assertNotNull("生成的帧不应为空", result);
    }
    
    @After
    public void tearDown() {
        model.close();
    }
}
```

### 6.2 性能测试

创建`PerformanceTest.java`：

```java
package com.example.imagetovideoapp.test;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.imagetovideoapp.model.LivePortraitModel;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.io.InputStream;

@RunWith(AndroidJUnit4.class)
public class PerformanceTest {
    private static final String TAG = "PerformanceTest";
    private Context context;
    private LivePortraitModel model;
    
    @Before
    public void setUp() {
        context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        model = new LivePortraitModel(context);
    }
    
    @Test
    public void testInferenceSpeed() throws IOException {
        // 加载测试图像
        InputStream sourceIs = context.getAssets().open("test_source.jpg");
        Bitmap sourceBitmap = BitmapFactory.decodeStream(sourceIs);
        sourceIs.close();
        
        InputStream drivingIs = context.getAssets().open("test_driving.jpg");
        Bitmap drivingBitmap = BitmapFactory.decodeStream(drivingIs);
        drivingIs.close();
        
        // 预热
        model.generateFrame(sourceBitmap, drivingBitmap);
        
        // 测试推理速度
        int numRuns = 10;
        long totalTime = 0;
        
        for (int i = 0; i < numRuns; i++) {
            long startTime = System.currentTimeMillis();
            model.generateFrame(sourceBitmap, drivingBitmap);
            long endTime = System.currentTimeMillis();
            
            long inferenceTime = endTime - startTime;
            totalTime += inferenceTime;
            
            Log.d(TAG, "Run " + (i + 1) + ": " + inferenceTime + " ms");
        }
        
        double averageTime = totalTime / (double) numRuns;
        Log.d(TAG, "Average inference time: " + averageTime + " ms");
    }
    
    @Test
    public void testMemoryUsage() throws IOException {
        // 加载测试图像
        InputStream sourceIs = context.getAssets().open("test_source.jpg");
        Bitmap sourceBitmap = BitmapFactory.decodeStream(sourceIs);
        sourceIs.close();
        
        InputStream drivingIs = context.getAssets().open("test_driving.jpg");
        Bitmap drivingBitmap = BitmapFactory.decodeStream(drivingIs);
        drivingIs.close();
        
        // 记录初始内存
        Runtime runtime = Runtime.getRuntime();
        long initialMemory = runtime.totalMemory() - runtime.freeMemory();
        
        // 生成多个帧
        for (int i = 0; i < 10; i++) {
            model.generateFrame(sourceBitmap, drivingBitmap);
        }
        
        // 记录最终内存
        long finalMemory = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = finalMemory - initialMemory;
        
        Log.d(TAG, "Memory used: " + (memoryUsed / 1024 / 1024) + " MB");
    }
    
    @After
    public void tearDown() {
        model.close();
    }
}
```

## 7. 部署清单

### 7.1 模型文件

- `kp_detector_quantized.onnx`：量化后的关键点检测器模型
- `generator_quantized.onnx`：量化后的生成器模型

### 7.2 Android项目文件

- `LivePortraitModel.java`：模型加载与推理类
- `VideoGenerationService.java`：视频生成服务类
- 相关UI界面和资源文件

### 7.3 测试文件

- `LivePortraitModelTest.java`：模型功能测试
- `PerformanceTest.java`：性能测试

## 8. 后续优化方向

1. **模型进一步轻量化**：探索更轻量级的模型架构，如MobileNet等
2. **硬件加速**：利用GPU/DSP加速计算，如OpenCL、Vulkan等
3. **自适应质量控制**：根据设备性能自动调整输出质量
4. **增量更新**：支持模型的在线更新和升级

## 9. 参考资料

1. [LivePortrait GitHub仓库](https://github.com/KwaiVGI/LivePortrait)
2. [ONNX Runtime Android文档](https://onnxruntime.ai/docs/tutorials/mobile/android.html)
3. [Android MediaCodec文档](https://developer.android.com/reference/android/media/MediaCodec)
4. [PyTorch Mobile文档](https://pytorch.org/mobile/android/)
5. [模型量化技术指南](https://onnxruntime.ai/docs/performance/model-optimizations/quantization.html)
